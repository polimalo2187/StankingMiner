export async function menuGanancias(ctx){
  ctx.editMessageText("💰 Ganancias",{parse_mode:"Markdown"});
}
