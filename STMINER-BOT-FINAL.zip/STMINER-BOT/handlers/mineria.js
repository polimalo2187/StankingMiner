export async function menuMineria(ctx){
  ctx.editMessageText("⛏ Minería",{parse_mode:"Markdown"});
}
