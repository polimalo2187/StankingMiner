import { supabase } from "../supabase.js";
import { Markup } from "telegraf";
import { verificarDeposito } from "../services/bscscan.js";
import { mainKeyboard } from "../keyboards/mainKeyboard.js";

export async function menuStaking(ctx){
  return ctx.editMessageText(
    `Deposite 10 USDT a:
${process.env.BOT_WALLET}`,
    {
      parse_mode:"Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.callback("✔ Confirmar Depósito","staking_confirmar")],
        [Markup.button.callback("🔙 Regresar","back_main")]
      ])
    }
  );
}

export async function confirmarDeposito(ctx){
  await supabase.from("users").update({staking_step:"txhash"}).eq("telegram_id",ctx.from.id);
  ctx.editMessageText("Envíe su TX Hash",{parse_mode:"Markdown"});
}

export async function verificarTxHashStaking(ctx, txHash){
  const r = await verificarDeposito(txHash, process.env.BOT_WALLET, 10);
  if(!r.ok) return ctx.reply("❌ Depósito inválido");
  await supabase.from("users").update({
    staking_active:true,
    staking_amount:10,
    staking_days_done:0,
    staking_step:null
  }).eq("telegram_id",ctx.from.id);
  ctx.reply("🎉 Staking activado", {...mainKeyboard(), parse_mode:"Markdown"});
}
