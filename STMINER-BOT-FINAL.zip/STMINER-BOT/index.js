import dotenv from "dotenv";
import { Telegraf } from "telegraf";
import { supabase } from "./supabase.js";
import { mainKeyboard } from "./keyboards/mainKeyboard.js";
import { startVerification, verifyCode } from "./handlers/start.js";
import { menuStaking, confirmarDeposito, verificarTxHashStaking } from "./handlers/staking.js";
import { menuReferidos } from "./handlers/referidos.js";
import { menuMineria } from "./handlers/mineria.js";
import { menuGanancias } from "./handlers/ganancias.js";
import { menuRetiro, procesarRetiro } from "./handlers/retiro.js";
import { menuSoporte } from "./handlers/soporte.js";

dotenv.config();
const bot = new Telegraf(process.env.BOT_TOKEN);

bot.start((ctx)=>startVerification(ctx));

bot.on("callback_query", async (ctx)=>{
    const data = ctx.callbackQuery.data;
    if(data==="staking") return menuStaking(ctx);
    if(data==="referidos") return menuReferidos(ctx);
    if(data==="mineria") return menuMineria(ctx);
    if(data==="ganancias") return menuGanancias(ctx);
    if(data==="retiro") return menuRetiro(ctx);
    if(data==="soporte") return menuSoporte(ctx);
    if(data==="staking_confirmar") return confirmarDeposito(ctx);
    if(data==="back_main") return ctx.editMessageText("Menú principal",{...mainKeyboard(),parse_mode:"Markdown"});
});

bot.on("text", async (ctx)=>{
    const userId = ctx.from.id;
    const { data: user } = await supabase.from("users").select("*").eq("telegram_id",userId).single();
    if(!user) return;

    if(user.verification_step==="waiting_code"){
        return verifyCode(ctx, ctx.message.text.trim());
    }

    if(user.staking_step==="txhash"){
        return verificarTxHashStaking(ctx, ctx.message.text.trim());
    }

    if(user.retiro_step==="awaiting_wallet" or user.retiro_step==="awaiting_amount"):
        return procesarRetiro(ctx, ctx.message.text.trim());
});

bot.launch();
