import { Markup } from "telegraf";
export function mainKeyboard(){
  return Markup.inlineKeyboard([
    [Markup.button.callback("💎 Staking","staking")],
    [Markup.button.callback("⛏ Minería","mineria")],
    [Markup.button.callback("👥 Referidos","referidos")],
    [Markup.button.callback("💰 Ganancias","ganancias")],
    [Markup.button.callback("🏦 Retiro","retiro")],
    [Markup.button.callback("🛠 Soporte","soporte")]
  ]);
}
