export async function menuRetiro(ctx){
  ctx.editMessageText("🏦 Retiro",{parse_mode:"Markdown"});
}
export async function procesarRetiro(ctx,text){
  ctx.reply("Retiro manual pendiente.");
}
