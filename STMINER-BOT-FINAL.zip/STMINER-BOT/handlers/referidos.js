export async function menuReferidos(ctx){
  ctx.editMessageText("👥 Referidos",{parse_mode:"Markdown"});
}
