import { supabase } from "../supabase.js";

export async function startVerification(ctx){
  const code = Math.floor(100000+Math.random()*900000);
  await supabase.from("users").upsert({
    telegram_id:ctx.from.id,
    verification_code:code,
    verification_step:"waiting_code"
  });
  ctx.reply(`Tu código es: *${code}*`,{parse_mode:"Markdown"});
}

export async function verifyCode(ctx, code){
  const userId = ctx.from.id;
  const { data:user } = await supabase.from("users").select("*").eq("telegram_id",userId).single();
  if(String(code)!==String(user.verification_code))
      return ctx.reply("❌ Código incorrecto");
  await supabase.from("users").update({verification_step:"verified"}).eq("telegram_id",userId);
  ctx.reply("✅ Verificado",{parse_mode:"Markdown"});
}
