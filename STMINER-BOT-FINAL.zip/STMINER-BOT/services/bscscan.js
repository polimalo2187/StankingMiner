import axios from "axios";

export async function verificarDeposito(txHash, walletDestinoEsperada, montoEsperado){
  try{
    const url = `https://api.bscscan.com/api?module=proxy&action=eth_getTransactionByHash&txhash=${txHash}&apikey=${process.env.BSCSCAN_API_KEY}`;
    const { data } = await axios.get(url);
    if(!data.result) return { ok:false, error:"TX inválida." };
    const tx = data.result;
    const input = tx.input.toLowerCase();
    const montoHex = input.slice(-64);
    const montoReal = parseInt(montoHex,16)/1e18;
    if(montoReal < montoEsperado) return {ok:false,error:"Monto insuficiente"};
    return {ok:true,monto:montoReal};
  } catch(e){
    return {ok:false, error:"Error interno"};
  }
}
